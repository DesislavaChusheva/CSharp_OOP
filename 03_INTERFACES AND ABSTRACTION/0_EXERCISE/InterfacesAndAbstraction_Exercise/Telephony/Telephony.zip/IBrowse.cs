﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public interface IBrowse
    {
        string Browsing(string website);
    }
}
