﻿using System;

namespace Vehicles
{
    public class Program
    {
        static void Main(string[] args)
        {
            string[] carI = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            Car car = new Car(double.Parse(carI[1]), double.Parse(carI[2]));
            string[] truckI = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            Truck truck = new Truck(double.Parse(truckI[1]), double.Parse(truckI[2]));
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string[] command = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                string action = command[0];
                string vehicle = command[1];
                double kmOrLt = double.Parse(command[2]);
                switch (action)
                {
                    case "Drive":
                        if (vehicle == "Car")
                        {
                            car.Drive(kmOrLt);
                        }
                        else if (vehicle == "Truck")
                        {
                            truck.Drive(kmOrLt);
                        }
                        break;
                    case "Refuel":
                        if (vehicle == "Car")
                        {
                            car.Refuel(kmOrLt);
                        }
                        else if (vehicle == "Truck")
                        {
                            truck.Refuel(kmOrLt);
                        }
                        break;
                    default:
                        break;
                }
            }
            Console.WriteLine($"Car: {car.FuelQuantity:f2}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:f2}");
        }
    }
}
