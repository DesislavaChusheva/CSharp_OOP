﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public class Truck : IVehicle
    {
        private const double increaseLt = 1.6;
        public Truck(double fuelQuantity, double consumption)
        {
            FuelQuantity = fuelQuantity;
            Consumption = consumption + increaseLt;
        }
        public double FuelQuantity { get; private set; }

        public double Consumption { get; private set; }

        public void Drive(double km)
        {
            double needeFuel = Consumption * km;
            if (needeFuel > FuelQuantity)
            {
                Console.WriteLine("Truck needs refueling");
                return;
            }
            FuelQuantity -= needeFuel;
            Console.WriteLine($"Truck travelled {km} km");
        }

        public void Refuel(double lt)
        {
            FuelQuantity += lt * 0.95;
        }
    }
}
