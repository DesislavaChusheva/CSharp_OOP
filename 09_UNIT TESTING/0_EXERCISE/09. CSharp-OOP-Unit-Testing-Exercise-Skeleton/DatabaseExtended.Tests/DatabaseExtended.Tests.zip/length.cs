﻿namespace Tests
{
    internal class length
    {
    }
}